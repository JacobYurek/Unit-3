/**
 * https://simplestatistics.org/docs/#subtractfrommean
 */
declare function subtractFromMean(
  mean: number,
  n: number,
  value: number
): number;

export default subtractFromMean;
