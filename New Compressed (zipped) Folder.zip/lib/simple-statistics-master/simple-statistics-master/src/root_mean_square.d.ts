/**
 * https://simplestatistics.org/docs/#rootmeansquare
 */
declare function rootMeanSquare(x: number[]): number;

export default rootMeanSquare;
