/**
 * https://simplestatistics.org/docs/#samplerankcorrelation
 */
declare function sampleRankCorrelation(x: number[], y: number[]): number;

export default sampleRankCorrelation;
