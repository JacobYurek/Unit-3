/**
 * https://simplestatistics.org/docs/#sign
 */
declare function sign(x: number): number;

export default sign;
