/**
 * https://simplestatistics.org/docs/#interquartilerange
 */
declare function interquartileRange(x: number[]): number;

export default interquartileRange;
