/**
 * https://simplestatistics.org/docs/#coefficientofvariation
 */
declare function coefficientOfVariation(x: number[]): number;

export default coefficientOfVariation;
