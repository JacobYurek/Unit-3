/**
 * https://simplestatistics.org/docs/#median
 */
declare function median(x: number[]): number;

export default median;
