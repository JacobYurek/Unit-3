/**
 * https://simplestatistics.org/docs/#sumsimple
 */
declare function sumSimple(x: number[]): number;

export default sumSimple;
