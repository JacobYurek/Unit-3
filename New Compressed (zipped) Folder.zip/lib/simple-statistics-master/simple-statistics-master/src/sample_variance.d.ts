/**
 * https://simplestatistics.org/docs/#samplevariance
 */
declare function sampleVariance(x: number[]): number;

export default sampleVariance;
