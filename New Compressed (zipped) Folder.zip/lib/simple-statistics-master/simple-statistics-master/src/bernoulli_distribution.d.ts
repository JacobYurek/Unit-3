/**
 * https://simplestatistics.org/docs/#bernoullidistribution
 */
declare function bernoulliDistribution(p: number): number[];

export default bernoulliDistribution;
