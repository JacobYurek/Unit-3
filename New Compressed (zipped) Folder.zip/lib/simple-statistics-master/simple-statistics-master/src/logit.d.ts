/**
 * https://simplestatistics.org/docs/#logit
 */
declare function logit(p: number): number;

export default logit;
