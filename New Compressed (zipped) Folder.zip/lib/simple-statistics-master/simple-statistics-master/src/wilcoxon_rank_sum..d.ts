/**
 * https://simplestatistics.org/docs/#wilcoxonranksum
 */
declare function wilcoxonRankSum(sampleX: number[], sampleY: number[]): number;

export default wilcoxonRankSum;
