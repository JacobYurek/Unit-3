/**
 * https://simplestatistics.org/docs/#samplecovariance
 */
declare function sampleCovariance(x: number[], y: number[]): number;

export default sampleCovariance;
