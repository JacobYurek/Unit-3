/**
 * https://simplestatistics.org/docs/#probit
 */
declare function probit(p: number): number;

export default probit;
