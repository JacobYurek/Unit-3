/**
 * https://simplestatistics.org/docs/#sampleskewness
 */
declare function sampleSkewness(x: number[]): number;

export default sampleSkewness;
