/**
 * https://simplestatistics.org/docs/#factorial
 */
declare function factorial(n: number): number;

export default factorial;
