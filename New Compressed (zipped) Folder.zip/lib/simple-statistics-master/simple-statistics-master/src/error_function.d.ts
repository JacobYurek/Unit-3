/**
 * https://simplestatistics.org/docs/#errorfunction
 */
declare function errorFunction(x: number): number;

export default errorFunction;
