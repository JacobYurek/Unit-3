/**
 * https://simplestatistics.org/docs/#modesorted
 */
declare function modeSorted(sorted: number[]): number;

export default modeSorted;
