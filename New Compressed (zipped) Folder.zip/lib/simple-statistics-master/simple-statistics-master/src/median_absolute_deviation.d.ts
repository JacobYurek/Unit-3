/**
 * https://simplestatistics.org/docs/#medianabsolutedeviation
 */
declare function medianAbsoluteDeviation(x: number[]): number;

export default medianAbsoluteDeviation;
