/**
 * https://simplestatistics.org/docs/#product
 */
declare function product(x: number[]): number;

export default product;
