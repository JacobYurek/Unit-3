/**
 * https://simplestatistics.org/docs/#standarddeviation
 */
declare function standardDeviation(x: number[]): number;

export default standardDeviation;
