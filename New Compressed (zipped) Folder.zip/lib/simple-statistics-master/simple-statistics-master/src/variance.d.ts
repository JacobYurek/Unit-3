/**
 * https://simplestatistics.org/docs/#variance
 */
declare function variance(x: number[]): number;

export default variance;
