/**
 * https://simplestatistics.org/docs/#modefast
 */
declare function modeFast<T extends any>(x: T[]): T;

export default modeFast;
