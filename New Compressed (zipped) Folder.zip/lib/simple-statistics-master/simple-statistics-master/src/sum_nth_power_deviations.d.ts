/**
 * https://simplestatistics.org/docs/#sumnthpowerdeviations
 */
declare function sumNthPowerDeviations(x: number[], n?: number): number;

export default sumNthPowerDeviations;
