/**
 * https://simplestatistics.org/docs/#cumulativestdlogisticprobability
 */
declare function cumulativeStdLogisticProbability(x: number): number;

export default cumulativeStdLogisticProbability;
