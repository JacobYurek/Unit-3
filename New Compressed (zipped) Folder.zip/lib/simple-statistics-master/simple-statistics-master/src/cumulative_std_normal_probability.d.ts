/**
 * https://simplestatistics.org/docs/#cumulativestdnormalprobability
 */
declare function cumulativeStdNormalProbability(z: number): number;

export default cumulativeStdNormalProbability;
