/**
 * https://simplestatistics.org/docs/#maxsorted
 */
declare function maxSorted(x: number[]): number;

export default maxSorted;
