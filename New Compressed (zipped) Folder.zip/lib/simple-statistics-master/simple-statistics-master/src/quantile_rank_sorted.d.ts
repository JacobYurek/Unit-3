/**
 * https://simplestatistics.org/docs/#quantileranksorted
 */
declare function quantileRankSorted(x: number[], value: number): number;

export default quantileRankSorted;
