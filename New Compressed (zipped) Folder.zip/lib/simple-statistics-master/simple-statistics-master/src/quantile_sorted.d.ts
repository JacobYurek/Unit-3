/**
 * https://simplestatistics.org/docs/#quantilesorted
 */
declare function quantileSorted(x: number[], p: number): number;

export default quantileSorted;
