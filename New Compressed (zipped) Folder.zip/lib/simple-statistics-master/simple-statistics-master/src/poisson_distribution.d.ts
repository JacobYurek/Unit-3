/**
 * https://simplestatistics.org/docs/#poissondistribution
 */
declare function poissonDistribution(lambda: number): number[];

export default poissonDistribution;
