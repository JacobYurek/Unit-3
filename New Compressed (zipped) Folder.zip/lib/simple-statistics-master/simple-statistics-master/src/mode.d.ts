/**
 * https://simplestatistics.org/docs/#mode
 */
declare function mode(x: number[]): number;

export default mode;
