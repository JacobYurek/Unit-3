/**
 * https://simplestatistics.org/docs/#mean
 */
declare function meanSimple(x: number[]): number;

export default meanSimple;
