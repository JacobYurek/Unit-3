/**
 * https://simplestatistics.org/docs/#mediansorted
 */
declare function medianSorted(sorted: number[]): number;

export default medianSorted;
