/**
 * https://simplestatistics.org/docs/#addtomean
 */
declare function addToMean(mean: number, n: number, newValue: number): number;

export default addToMean;
