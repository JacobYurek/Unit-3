/**
 * https://simplestatistics.org/docs/#inverseerrorfunction
 */
declare function inverseErrorFunction(x: number): number;

export default inverseErrorFunction;
