/**
 * https://simplestatistics.org/docs/#min
 */
declare function min(x: number[]): number;

export default min;
