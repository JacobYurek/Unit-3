/**
 * https://simplestatistics.org/docs/#relative_error
 */
declare function relativeError(actual: number, expected: number): number;

export default relativeError;
