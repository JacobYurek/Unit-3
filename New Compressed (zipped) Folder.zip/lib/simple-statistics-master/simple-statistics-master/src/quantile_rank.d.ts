/**
 * https://simplestatistics.org/docs/#quantilerank
 */
declare function quantileRank(x: number[], value: number): number;

export default quantileRank;
