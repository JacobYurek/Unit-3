/**
 * https://simplestatistics.org/docs/#samplecorrelation
 */
declare function sampleCorrelation(x: number[], y: number[]): number;

export default sampleCorrelation;
