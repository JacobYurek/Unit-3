/**
 * https://simplestatistics.org/docs/#quantile
 */
declare function quantile(x: number[], p: number): number;
declare function quantile(x: number[], p: number[]): number[];

export default quantile;
