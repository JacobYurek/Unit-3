/**
 * https://simplestatistics.org/docs/#standardnormaltable
 */
declare const standardNormalTable: number[];

export default standardNormalTable;
