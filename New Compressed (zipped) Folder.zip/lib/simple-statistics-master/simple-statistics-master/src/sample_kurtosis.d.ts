/**
 * https://simplestatistics.org/docs/#samplekurtosis
 */
declare function sampleKurtosis(x: number[]): number;

export default sampleKurtosis;
