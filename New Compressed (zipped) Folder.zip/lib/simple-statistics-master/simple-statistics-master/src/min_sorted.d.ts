/**
 * https://simplestatistics.org/docs/#minsorted
 */
declare function minSorted(x: number[]): number;

export default minSorted;
