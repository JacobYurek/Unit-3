/**
 * https://simplestatistics.org/docs/#extent
 */
declare function extent(x: number[]): [number, number];

export default extent;
