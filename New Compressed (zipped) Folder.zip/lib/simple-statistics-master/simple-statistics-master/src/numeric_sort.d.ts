/**
 * https://simplestatistics.org/docs/#numericsort
 */
declare function numericSort(x: number[]): number[];

export default numericSort;
