/**
 * https://simplestatistics.org/docs/#mean
 */
declare function mean(x: number[]): number;

export default mean;
