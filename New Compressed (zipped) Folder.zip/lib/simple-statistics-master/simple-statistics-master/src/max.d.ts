/**
 * https://simplestatistics.org/docs/#max
 */
declare function max(x: number[]): number;

export default max;
