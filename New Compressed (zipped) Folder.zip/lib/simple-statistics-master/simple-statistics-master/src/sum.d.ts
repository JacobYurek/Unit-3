/**
 * https://simplestatistics.org/docs/#sum
 */
declare function sum(x: number[]): number;

export default sum;
