/**
 * https://simplestatistics.org/docs/#ttest
 */
declare function tTest(x: number[], expectedValue: number): number;

export default tTest;
