/**
 * https://simplestatistics.org/docs/#permutationsheap
 */
declare function permutationsHeap<T extends any[]>(elements: T): T[];

export default permutationsHeap;
