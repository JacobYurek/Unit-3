/**
 * https://simplestatistics.org/docs/#silhouette
 */
declare function silhouette(points: number[][], labels: number[]): number[];

export default silhouette;
