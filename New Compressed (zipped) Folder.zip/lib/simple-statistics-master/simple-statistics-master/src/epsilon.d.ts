/**
 * https://simplestatistics.org/docs/#epsilon
 */
declare const epsilon: number;

export default epsilon;
