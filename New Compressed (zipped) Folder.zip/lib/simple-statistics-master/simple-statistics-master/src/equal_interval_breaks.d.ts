/**
 * https://simplestatistics.org/docs/#equalintervalbreaks
 */
declare function equalIntervalBreaks(x: number[], nClasses: number): number[];

export default equalIntervalBreaks;
