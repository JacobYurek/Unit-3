/**
 * https://simplestatistics.org/docs/#geometricmean
 */
declare function geometricMean(x: number[]): number;

export default geometricMean;
