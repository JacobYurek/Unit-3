/**
 * https://simplestatistics.org/docs/#harmonicmean
 */
declare function harmonicMean(x: number[]): number;

export default harmonicMean;
