/**
 * https://simplestatistics.org/docs/#uniquecountsorted
 */
declare function uniqueCountSorted(x: any[]): number;

export default uniqueCountSorted;
