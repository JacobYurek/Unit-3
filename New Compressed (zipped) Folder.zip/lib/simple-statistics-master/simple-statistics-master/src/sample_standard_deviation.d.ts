/**
 * https://simplestatistics.org/docs/#samplestandarddeviation
 */
declare function sampleStandardDeviation(x: number[]): number;

export default sampleStandardDeviation;
